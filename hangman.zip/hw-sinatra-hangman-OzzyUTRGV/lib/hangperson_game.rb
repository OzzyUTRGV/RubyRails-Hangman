#NAMES: Osvaldo Garza, Francisco Aguillon 
class HangpersonGame

  # add the necessary class methods, attributes, etc. here
  # to make the tests in spec/hangperson_game_spec.rb pass.

  # Get a word from remote "random word" service

  # def initialize()
  # end
  
  attr_accessor :word
  attr_accessor :guesses
  attr_accessor :wrong_guesses

  def initialize(word)
    @word = word
    @guesses = ""
    @wrong_guesses = ""
    #@guess = ""
  end

#   def word()
#     @word
#   end

#   def guesses()
#     if @word.include? @guess
#       @guesses.concat(@guess)
#     else
#       @guesses
#     end
#   end

#   def wrong_guesses()
#     if not(@word.include?(@guess))
#       @wrong_guesses.concat(@guess)
#     else
#       @wrong_guesses
#     end
#   end

  def guess(guess)
    if(guess == nil || guess == "" || guess.match?(/[^a-zA-Z]/))
        raise ArgumentError
    end

    @guess = guess.downcase

    if (@guesses + @wrong_guesses).include?(@guess)
      return false
    else
      if @word.include? @guess
        @guesses.concat(@guess)
      else
        @guesses
      end

      if not(@word.include?(@guess))
        @wrong_guesses.concat(@guess)
      else
        @wrong_guesses
      end

      return true
    end
  end

  def word_with_guesses
    #array from @word characters
    characters = @word.chars

    #array of word that is covered
    hidden_word = []

    #If letter, in @word is found in @guesses then reveal it else keep hidden
    characters.each do |letter|
      if @guesses.include?(letter)
        hidden_word << letter
      else
        hidden_word << '-'
      end
    end

    #turn array back into string
    revealed_word = hidden_word.join
  end
  
  def check_win_or_lose
    if not word_with_guesses.include? '-'
        return :win
    elsif @wrong_guesses.length > 6
        return :lose
    else
        return :play
    end
  end

  # You can test it by running $ bundle exec irb -I. -r app.rb
  # And then in the irb: irb(main):001:0> HangpersonGame.get_random_word
  #  => "cooking"   <-- some random word
  def self.get_random_word
    require 'uri'
    require 'net/http'
    uri = URI('http://randomword.saasbook.info/RandomWord')
    Net::HTTP.new('randomword.saasbook.info').start { |http|
      return http.post(uri, "").body
    }
  end

end
